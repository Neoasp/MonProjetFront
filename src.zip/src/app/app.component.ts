import { Component } from '@angular/core';
import {Adherent, AdherentQueryService} from './core/services/adherent-query.service'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'monProjet';
  adherents: Adherent[] = [];
  

  constructor (private adherentQueryService: AdherentQueryService) {
    let a: Adherent;
    a = {id:0, lastName:'', firstName:'', prenom: ''};
    //a.prenom = 'toto';
  }

  ngOnInit() {
    this.adherentQueryService.getAdherents().subscribe (
      result => this.adherents = result
    );
  }

}
